import 'package:flutter_test/flutter_test.dart';
import 'package:my_plugin_hello/my_plugin_hello.dart';
import 'package:my_plugin_hello/my_plugin_hello_platform_interface.dart';
import 'package:my_plugin_hello/my_plugin_hello_method_channel.dart';
import 'package:plugin_platform_interface/plugin_platform_interface.dart';

class MockMyPluginHelloPlatform
    with MockPlatformInterfaceMixin
    implements MyPluginHelloPlatform {

  @override
  Future<String?> getPlatformVersion() => Future.value('42');
}

void main() {
  final MyPluginHelloPlatform initialPlatform = MyPluginHelloPlatform.instance;

  test('$MethodChannelMyPluginHello is the default instance', () {
    expect(initialPlatform, isInstanceOf<MethodChannelMyPluginHello>());
  });

  test('getPlatformVersion', () async {
    MyPluginHello myPluginHelloPlugin = MyPluginHello();
    MockMyPluginHelloPlatform fakePlatform = MockMyPluginHelloPlatform();
    MyPluginHelloPlatform.instance = fakePlatform;

    expect(await myPluginHelloPlugin.getPlatformVersion(), '42');
  });
}
