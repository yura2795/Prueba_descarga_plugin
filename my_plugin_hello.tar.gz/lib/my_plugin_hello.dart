
import 'my_plugin_hello_platform_interface.dart';

class MyPluginHello {
  Future<String?> getPlatformVersion() {
    return MyPluginHelloPlatform.instance.getPlatformVersion();
  }


  String helloText() {
    const text = "Hello World";
    return text;
  }
}
