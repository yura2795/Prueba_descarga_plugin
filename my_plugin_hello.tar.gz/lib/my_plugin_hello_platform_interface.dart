import 'package:plugin_platform_interface/plugin_platform_interface.dart';

import 'my_plugin_hello_method_channel.dart';

abstract class MyPluginHelloPlatform extends PlatformInterface {
  /// Constructs a MyPluginHelloPlatform.
  MyPluginHelloPlatform() : super(token: _token);

  static final Object _token = Object();

  static MyPluginHelloPlatform _instance = MethodChannelMyPluginHello();

  /// The default instance of [MyPluginHelloPlatform] to use.
  ///
  /// Defaults to [MethodChannelMyPluginHello].
  static MyPluginHelloPlatform get instance => _instance;

  /// Platform-specific implementations should set this with their own
  /// platform-specific class that extends [MyPluginHelloPlatform] when
  /// they register themselves.
  static set instance(MyPluginHelloPlatform instance) {
    PlatformInterface.verifyToken(instance, _token);
    _instance = instance;
  }

  Future<String?> getPlatformVersion() {
    throw UnimplementedError('platformVersion() has not been implemented.');
  }
}
